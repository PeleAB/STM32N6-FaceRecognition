#!/bin/bash

# Activate the virtual environment
source /opt/workshop-env/bin/activate

# Launch JupyterLab and open the notebook
jupyter lab EdgeAI_Workshop_Pipeline.ipynb
